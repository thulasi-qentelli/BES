//
//  ForgotPWDViewController.swift
//  BES
//
//  Created by Thulasi Ram Boddu on 21/08/19.
//  Copyright © 2019 Qentelli. All rights reserved.
//

import UIKit

class ForgotPWDViewController: UIViewController {

    @IBOutlet weak var emailView: InputView!
    @IBOutlet weak var sendLinkBtn: UIButton!
    @IBOutlet weak var resendBtn: UIButton!
    @IBOutlet weak var backBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        
        let backbutton = UIButton(type: .custom)
        backbutton.setImage(UIImage(named: "arrow_back"), for: .normal)
        backbutton.addTarget(self, action: #selector(backBtnAction), for: .touchUpInside)
        
        let barButton = UIBarButtonItem(customView: backbutton)
        
        let currWidth = barButton.customView?.widthAnchor.constraint(equalToConstant: 24)
        currWidth?.isActive = true
        let currHeight = barButton.customView?.heightAnchor.constraint(equalToConstant: 24)
        currHeight?.isActive = true
        self.navigationItem.leftBarButtonItem = barButton
        
    }
    
    @objc func backBtnAction() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    func setupUI() {
        emailView.titleLbl.text = "Email address"
        emailView.txtField.placeholder = "Enter email address"
        
    }
    
    @IBAction func btnAction(_ sender: UIButton) {
        
        if sender == sendLinkBtn || sender == resendBtn {

            let alertVC     =   AcknowledgeViewController()
            alertVC.type    =   .ForgotPassword
            self.navigationController?.pushViewController(alertVC, animated: true)
        }
        else if sender == backBtn {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
}
