//
//  ForgotPWDViewController.swift
//  BES
//
//  Created by Thulasi Ram Boddu on 21/08/19.
//  Copyright © 2019 Qentelli. All rights reserved.
//

import UIKit

class ForgotPWDViewController: UIViewController {

    @IBOutlet weak var emailView: InputView!
    @IBOutlet weak var sendLinkBtn: UIButton!
    @IBOutlet weak var resendBtn: UIButton!
    @IBOutlet weak var backBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    func setupUI() {
        emailView.titleLbl.text = "Email address"
        emailView.txtField.placeholder = "Enter email address"
        
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btnAction(_ sender: UIButton) {
        
        if sender == sendLinkBtn || sender == resendBtn {

            let alertVC     =   AcknowledgeViewController()
            alertVC.type    =   .ForgotPassword
            self.navigationController?.pushViewController(alertVC, animated: true)
        }
        else if sender == backBtn {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
}
