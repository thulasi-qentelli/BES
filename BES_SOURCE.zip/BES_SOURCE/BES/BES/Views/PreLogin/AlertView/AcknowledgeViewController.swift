//
//  AcknowledgeViewController.swift
//  BES
//
//  Created by Thulasi Ram Boddu on 21/08/19.
//  Copyright © 2019 Qentelli. All rights reserved.
//

import UIKit
enum AcknowledgeType {
    case Signup
    case ForgotPassword
}
class AcknowledgeViewController: UIViewController {

    var type:AcknowledgeType = .ForgotPassword
    var email:String = ""
    @IBOutlet weak var clickHereHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var alertImageView: UIImageView!
    @IBOutlet weak var alertTitleLbl: UILabel!
    @IBOutlet weak var alertDetailLbl: UILabel!
    @IBOutlet weak var clickHereBtn: UIButton!
    @IBOutlet weak var doneBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func setupUI() {
        switch type {
        case .ForgotPassword:
            titleLbl.text = "Forgot\nPassword?"
            alertTitleLbl.text = "Password reset sent"
            alertDetailLbl.text = "We've emailed you the instructions for setting your password, if an account exists with the email you entered\n\nIf you didn't receive an email, please make sure you've entered the email address you registered with, and check your spam folder."
            clickHereHeightConstraint.constant = 0
            doneBtn.setTitle("DONE", for: .normal)
        case .Signup:
            titleLbl.text = "New\nAccount"
            alertTitleLbl.text = "Email Verification Required"
            alertDetailLbl.text = "Am email has been sent to:\n\(self.email)\n\nPlease follow the instructions in the verification email to finish creating your BES account."
            doneBtn.setTitle("DONE", for: .normal)
     
        }
    }
    @IBAction func btnAction(_ sender: UIButton) {
        if sender == clickHereBtn {
            
        }
        else if sender == doneBtn {
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
}
