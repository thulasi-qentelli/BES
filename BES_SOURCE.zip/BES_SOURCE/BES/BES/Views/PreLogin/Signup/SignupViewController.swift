//
//  SignupViewController.swift
//  BES
//
//  Created by Thulasi Ram Boddu on 21/08/19.
//  Copyright © 2019 Qentelli. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {

    
    @IBOutlet weak var profileHeaderView: ProfileHeaderView!
    @IBOutlet weak var firstNameView: InputView!
    @IBOutlet weak var lastNameView: InputView!
    @IBOutlet weak var emailView: InputView!
    @IBOutlet weak var passwordView: InputView!
    @IBOutlet weak var confirmPasswordView: InputView!
    @IBOutlet weak var createAccountBtn: UIButton!
    @IBOutlet weak var signInBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.view.backgroundColor = .clear
        self.navigationController?.isNavigationBarHidden = false
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func setupUI() {
        
        firstNameView.titleLbl.text = "First Name"
        firstNameView.txtField.placeholder = "Enter first name"
        
        lastNameView.titleLbl.text = "Last Name"
        lastNameView.txtField.placeholder = "Enter last name"
        
        emailView.titleLbl.text = "Email address"
        emailView.txtField.placeholder = "Enter email address"
        emailView.txtField.keyboardType = .emailAddress
        
        passwordView.titleLbl.text = "Password"
        passwordView.txtField.placeholder = "Enter password"
        passwordView.txtField.isSecureTextEntry = true
        
        confirmPasswordView.titleLbl.text = "Confirm password"
        confirmPasswordView.txtField.placeholder = "Confirm password"
        confirmPasswordView.txtField.isSecureTextEntry = true
 
    }
    @IBAction func btnAction(_ sender: UIButton) {
        if sender == createAccountBtn {
            print("Create Account action")
            let alertVC     =   AcknowledgeViewController()
            alertVC.type    =   .Signup
            alertVC.email   =   emailView.txtField.text ?? ""
            self.navigationController?.pushViewController(alertVC, animated: true)
        }
        else if sender == signInBtn {
            print("Sign In action")
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
}
