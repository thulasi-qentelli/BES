//
//  LoginViewController.swift
//  BES
//
//  Created by Thulasi Ram Boddu on 21/08/19.
//  Copyright © 2019 Qentelli. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var userNameView: InputView!
    @IBOutlet weak var passwordView: InputView!
    @IBOutlet weak var signInBtn: UIButton!
    @IBOutlet weak var forgotPasswordBtn: UIButton!
    @IBOutlet weak var createAccountBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    func setupUI() {
        forgotPasswordBtn.titleLabel?.numberOfLines = 1
        forgotPasswordBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        createAccountBtn.titleLabel?.numberOfLines = 1
        createAccountBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        
        userNameView.titleLbl.text = "Username"
        userNameView.txtField.placeholder = "Enter email"
        userNameView.txtField.keyboardType = .emailAddress
        
        passwordView.titleLbl.text = "Password"
        passwordView.txtField.placeholder = "Enter password"
        passwordView.txtField.isSecureTextEntry = true
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btnAction(_ sender: UIButton) {
        
        if sender == signInBtn {
            print("Sign in action")
            AppController.shared.loadHomeView()
        }
        else if sender == forgotPasswordBtn {
            print("Forgot Password action")
            let forgotVC = ForgotPWDViewController()
            self.navigationController?.pushViewController(forgotVC, animated: true)
        }
        else if sender == createAccountBtn {
            print("Create Account action")
            let signupVC = SignupViewController()
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
    }
    
}
